#!/bin/bash

# Quick deployment script for development testing
# This builds and runs StorySpark locally using Docker

set -e

echo "🚀 Quick deployment for testing..."

# Check if we're in the right directory
if [ ! -f "Dockerfile" ]; then
    echo "❌ Error: Please run this script from the deploy/ directory"
    exit 1
fi

# Stop existing containers
echo "🛑 Stopping existing containers..."
docker-compose down 2>/dev/null || true

# Build and start
echo "🏗️  Building and starting StorySpark..."
docker-compose up --build -d

# Wait for startup
echo "⏳ Waiting for application to start..."
sleep 15

# Check if it's running
if curl -f http://localhost:5001/health > /dev/null 2>&1; then
    echo "✅ StorySpark is running!"
    echo "🌐 Open: http://localhost:5001"
else
    echo "❌ Something went wrong. Checking logs..."
    docker-compose logs --tail=20
fi

echo "📋 Use 'docker-compose logs -f' to view logs"
echo "📋 Use 'docker-compose down' to stop"