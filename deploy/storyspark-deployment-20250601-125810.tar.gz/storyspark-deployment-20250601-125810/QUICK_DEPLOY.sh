#!/bin/bash
echo "🚀 StorySpark Quick Deploy"
echo "This script will set up StorySpark on a fresh Ubuntu VM"
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo "⚠️  Don't run this script as root. Run as a regular user with sudo access."
    exit 1
fi

# Check if we're on the right system
if ! command -v apt-get &> /dev/null; then
    echo "❌ This script is designed for Ubuntu/Debian systems"
    exit 1
fi

echo "📍 Current directory: $(pwd)"
echo "📂 Contents:"
ls -la

# Run VM setup if Docker isn't installed
if ! command -v docker &> /dev/null; then
    echo "🐳 Installing Docker and dependencies..."
    cd deploy/
    chmod +x setup_vm.sh
    sudo ./setup_vm.sh
    echo "✅ VM setup completed"
    echo ""
    echo "⚠️  IMPORTANT: You need to log out and log back in for Docker permissions to take effect"
    echo "   After logging back in, run this script again to continue deployment"
    exit 0
fi

# Check for required files
if [ ! -f "deploy/secrets/service-account.json" ]; then
    echo "❌ Missing: deploy/secrets/service-account.json"
    echo "📝 Please upload your Google service account JSON file to:"
    echo "   $(pwd)/deploy/secrets/service-account.json"
    exit 1
fi

if [ ! -f "deploy/.env" ]; then
    echo "📝 Creating environment file..."
    cp deploy/.env.example deploy/.env
    echo "⚠️  Please edit deploy/.env with your actual values:"
    echo "   - GEMINI_API_KEY"
    echo "   - GOOGLE_CLOUD_PROJECT"
    echo "   - SECRET_KEY (generate a random string)"
    echo ""
    echo "   Then run this script again."
    exit 1
fi

# Deploy
echo "🚀 Deploying StorySpark..."
cd deploy/
chmod +x deploy_cloud.sh
./deploy_cloud.sh

echo "🎉 Deployment completed!"
echo "🌐 Access your app at: http://$(curl -s ifconfig.me):5001"
