"""
Utility functions and helpers for StorySpark backend.
"""
